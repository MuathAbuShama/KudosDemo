# jQuery Flipster Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/oxQowz](https://codepen.io/shshaw/pen/oxQowz).

https://github.com/drien/jquery-flipster/